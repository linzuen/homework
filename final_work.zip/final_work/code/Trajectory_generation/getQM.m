%% ######################################################
% @func：  获取Q矩阵以及映射矩阵M
% @param： n_seg：分段数
%          n_order：多项式阶数 
%          ts：分段的每段所用时间
% @return：Q：Q矩阵
%          M：映射矩阵
% ######################################################
function [Q, M] = getQM(n_seg, n_order, ts)
    d_order = (n_order + 1)/2;                                              % minimun 根据阶数 来确定优化什么
    control_point_num = n_order + 1;                                        % 贝塞尔曲线的控制点 等于 贝塞尔曲线的阶数 + 1
    Q = [];
    M = [];
    M_k = getM(n_order);                                                    % 获得映射矩阵M
    for k = 1:n_seg
        % 计算第k段的Q_k 
        t_k = 1;
        s_k = ts(k);    % 归一化系数
        Q_k = zeros(control_point_num, control_point_num);
        for i = d_order:n_order
            for j = d_order:n_order
                Q_k(i+1,j+1) = factorial(i)/factorial(i-d_order)*...
                    factorial(j)/factorial(j-d_order)/...
                    (i+j-n_order)*t_k^(i+j-n_order)/s_k^(2*d_order - 3);
            end
        end
        Q = blkdiag(Q, Q_k);
        M = blkdiag(M, M_k);
    end
end