%% ######################################################
% @func： 生成轨迹
% @param： path：计算的路径点
% @return：trace：轨迹的位置，速度，加速度值
%          corridor：飞行走廊的区域
% ######################################################
function [trace,corridor] = Trajectory_generation(path)
    path = path - 0.5;

    n_order = 7;                                                             % minimun snap 对应于七阶多项式
    control_point_num = n_order + 1;                                         % 贝塞尔曲线的控制点 等于 贝塞尔曲线的阶数 + 1
    n_seg = size(path, 1);                                                   % 分段数
    
    % corridor 3行 （分段数） 列
    % --------------
    % X val 
    % Y val 
    % dilate size
    % --------------
    corridor = zeros(3, n_seg);                                              % 创建飞行走廊空间
    for i = 1:n_seg
        corridor(:, i) = [path(i, 1), path(i, 2), 0.5]';                     % 将路径点的x y坐标，以及膨胀的大小
    end

%% 定义每一段的时间，这里简单的将每段的时间都设置为1
    ts = zeros(n_seg, 1);                                       
    for i = 1:n_seg
        ts(i,1) = 1;                                                         % 每段贝塞尔曲线的时间
    end
    % 获取x和y方向的多项式系数
    poly_coef_x = MinimumSnapCorridorBezierSolver(1, path(:, 1), corridor, ts, n_seg, n_order);
    poly_coef_y = MinimumSnapCorridorBezierSolver(2, path(:, 2), corridor, ts, n_seg, n_order);
%% 计算相应的贝塞尔曲线
    x_pos = [];y_pos = [];
    v1=[]; v2=[];
    a1=[]; a2=[];
    idx = 1;
    idv = 1;
    ida = 1;
   
    for k = 1:n_seg                                                                                          % 分段贝塞尔曲线
        for t = 0:0.01:1                                                                                     % 计算一段贝塞尔曲线
            x_pos(idx) = 0.0;                                                                                % 存储每个dt的x位置
            y_pos(idx) = 0.0;                                                                                % 存储每个dt的y位置
            for i = 0:n_order                                                                                % 代表第i个控制点 
                % 伯恩斯坦 基函数
                basis_p = nchoosek(n_order, i) * t^i * (1-t)^(n_order-i);                                    % 此处的nchoosek对应于C_n_i 二项式系数
                x_pos(idx) = x_pos(idx) + poly_coef_x( (k-1)* control_point_num + i + 1 ) * basis_p * ts(k); % 计算 x轴数值 计算每一个dt下 每一个控制点的作用
                y_pos(idx) = y_pos(idx) + poly_coef_y( (k-1)* control_point_num + i + 1 ) * basis_p * ts(k); % 计算 y轴数值 计算每一个dt下 每一个控制点的作用
            end
            idx = idx + 1;                                                                                   % 存储空间+1
            
            v1(idv) = 0.0;
            v2(idv) = 0.0;
            for i = 0:n_order - 1
                % 伯恩斯坦 基函数
                basis_p = nchoosek(n_order-1, i) * t^i * (1-t)^(n_order-1-i);                                    % 此处的nchoosek对应于C_n_i 二项式系数
                v1(idv) = v1(idv) + n_order*( poly_coef_x( (k-1)* control_point_num + i + 2 ) - ...
                                              poly_coef_x( (k-1)* control_point_num + i + 1 ) )...
                                              * basis_p * ts(k);
                v2(idv) = v2(idv) + n_order*( poly_coef_y( (k-1)* control_point_num + i + 2 ) - ...
                              poly_coef_y( (k-1)* control_point_num + i + 1 ) )...
                              * basis_p * ts(k);
            end
            idv = idv + 1;
            
            a1(ida) = 0.0;
            a2(ida) = 0.0;
            for i = 0:n_order - 2
                % 伯恩斯坦 基函数
                basis_p = nchoosek(n_order-2, i) * t^i * (1-t)^(n_order-2-i);                                    % 此处的nchoosek对应于C_n_i 二项式系数
                a1(ida) = a1(ida) + n_order*(n_order-1)*( poly_coef_x( (k-1)* control_point_num + i + 3 ) - ...
                                              2*poly_coef_x( (k-1)* control_point_num + i + 2 ) ) +...
                                              poly_coef_x( (k-1)* control_point_num + i + 1 )...
                                              * basis_p * ts(k);
                a2(ida) = a2(ida) + n_order*(n_order-1)*( poly_coef_y( (k-1)* control_point_num + i + 3 ) - ...
                                             2*poly_coef_y( (k-1)* control_point_num + i + 2 )+...
                                             poly_coef_y( (k-1)* control_point_num + i + 1 ) )...
                                             * basis_p * ts(k);
            end
            ida = ida + 1;  
        end
    end
    % trace 2列
    % --------------
    %  X val | Y val |
    % --------------
    trace = [x_pos',y_pos',v1',v2',(a1*0.001)',a2'];                                                                                 % 因为存储 x，y位置的时候是数组形式，现在转换成列存储

end
%% 求解贝塞尔多项式系数
function poly_coef = MinimumSnapCorridorBezierSolver(axis, waypoints, corridor, ts, n_seg, n_order)
    % 起点和终点条件
    start_cond = [waypoints(1), 0, 0];
    end_cond   = [waypoints(end), 0, 0];   
    
    % 计算对应于普通多项式的Q矩阵和对应于贝塞尔曲线的Q_0矩阵
    [Q, M]  = getQM(n_seg, n_order, ts);
    Q_0 = M'*Q*M;
    Q_0 = nearestSPD(Q_0);                          
    
    % 获取相应的等式约束
    [Aeq, beq] = getAbeq(n_seg, n_order, ts, start_cond, end_cond);                                     % 获得不等式系数，以及限制
    
    % 获取飞行走廊中各个区域的范围以及相应的不等式约束
    % corridor_range 2列
    % --------------
    %  Xmin | Xmax |
    % --------------
    corridor_range = [];
    for k = 1:n_seg
        corridor_range(k,:) = [corridor(axis,k) - corridor(end,k), corridor(axis,k) + corridor(end,k)]; % 适当膨胀飞行走廊，生成p_min,p_max.
    end
    [Aieq, bieq] = getAbieq(n_seg, n_order, corridor_range, ts);                                        % 获得不等式系数，以及限制
    
    f = zeros(size(Q_0,1),1);                                                                           % 输入不做优化
    poly_coef = quadprog(Q_0,f,Aieq, bieq, Aeq, beq);                                                   % 计算QP
end

