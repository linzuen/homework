%% ######################################################
% @func： 计算并返回标准QP不等式
% @param： n_seg：分段数
%          n_order：多项式阶数 
%          corridor_range：飞行走廊的位置上下限
%          ts：分段的每段所用时间
% @return：Aieq：不等式系数
%          bieq：限制
% ######################################################
function [Aieq, bieq] = getAbieq(n_seg, n_order, corridor_range, ts)

    control_point_num = n_order + 1;                                         % 贝塞尔曲线的控制点 等于 贝塞尔曲线的阶数 + 1
    n_all_poly = n_seg* control_point_num;                                   % 使用分段贝塞尔曲线，对应有（ n_seg 个段数 * control_point_num 控制点个数 ）的 多项式系数

    % 以下都使用了贝塞尔曲线的 Hodograph 的性质，也就是贝塞尔曲线的导数仍然是贝塞尔曲线（低一阶）
%% 设置位置约束  -p_min <= c^(i)_uj <= p_max (i为第i个控制点，u为[x,y]不同的轴 ,为第j段曲线）
    v = ones(n_all_poly,1);
    
    % 将时间T乘入到每个位置
    for i = 0:n_seg - 1     
        v(i *control_point_num + 1:(i+1) * control_point_num ) = v(i * control_point_num + 1:(i+1) * control_point_num) * ts(i+1);
    end
    
    Aieq_p = diag(v);                                                                                         % 按照对角矩阵放置元素 ( n_all_poly x n_all_poly ) 矩阵
    bieq_p = zeros(2*n_all_poly,1);                                                                           % 为了满足上下限，2倍
    for i = 0:n_seg - 1
        bieq_p(i * control_point_num + 1:i * control_point_num + n_order + 1) = corridor_range(i+1,2);        % 设置位置上限
        bieq_p(n_all_poly + i * control_point_num + 1:n_all_poly + i * control_point_num + n_order + 1)...    % 设置位置下限
            = (-1) * corridor_range(i + 1,1);
    end
    Aieq_p = [Aieq_p;-Aieq_p];
    
%% 设置速度约束  - v_m <= n*(c^i_uj - c^i-1_uj) <= v_m (i为第i个控制点，u为[x,y]不同的轴 ,为第j段曲线）
    Aieq_v = zeros(n_order * n_seg, n_all_poly);                                                              % 速度是低一阶的贝塞尔 少1个控制点
    j = 1;
    for i = 1:n_order * n_seg
        Aieq_v(i,j:j+1) = n_order * [-1, 1];                                                                  % 求导得来的系数
        if mod(j + 1,control_point_num) == 0                                                                  % 取模 每8个，跳1位 空一个出来 对应7个控制点 因为最后要
            j = j + 2;                                                                                        % 组合，所以列必须相等
        else
            j = j + 1;                                                                                        % 否则就逐步加
        end
    end
    
    Aieq_v = [Aieq_v;-Aieq_v];                                              
    bieq_v = ones(2 * n_order * n_seg,1)* 100;                                                                % 对应行设置上下限，默认上下限 都是 100

%% 设置加速度约束  - a_m <= n*(n-1)(c^i+1_uj -2* c^i-1_uj + c^i_uj ) <= a_m  (i为第i个控制点，u为[x,y]不同的轴 ,为第j段曲线）
  
    Aieq_a = zeros((n_order - 1) * n_seg, n_all_poly);                                                        % 加速度是低两阶的贝塞尔 少2个控制点
    j = 1;
    for i = 1:(n_order - 1) * n_seg
        Aieq_a(i,j:j+2) = n_order * (n_order - 1)*[1, -2, 1]/ts(floor(j/(n_order + 1)) + 1);                  % 求导得来的系数
        if mod(j + 2, control_point_num) == 0                                                                 % 取模 每8个，跳2位 空2个出来 对应6个控制点 因为最后要
            j = j + 3;                                                                                        % 组合，所以列必须相等
        else
            j = j + 1;                                                                                        % 否则就逐步加
        end
    end
    
    Aieq_a = [Aieq_a;-Aieq_a];                                              
    bieq_a = ones(2*(n_order - 1) * n_seg,1)*100;                                                             % 对应行设置上下限，默认上下限 都是 100

%% 组合所有约束构成不等式约束 
    Aieq = [Aieq_p; Aieq_v; Aieq_a];
    bieq = [bieq_p; bieq_v; bieq_a];
    
end