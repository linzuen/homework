%% ######################################################
% @func： 计算并返回标准QP等式
% @param： n_seg：分段数
%          n_order：多项式阶数 
%          ts：分段的每段所用时间
%          start_cond：开始条件
%          end_cond：终点条件
% @return：Aeq：等式系数
%          beq：限制
% ######################################################
function [Aeq, beq] = getAbeq(n_seg, n_order, ts, start_cond, end_cond)

    d_order = (n_order + 1)/2;                                              % minimun snap 就是最小化 四阶的二次型
    control_point_num = n_order + 1;                                        % 贝塞尔曲线的控制点 等于 贝塞尔曲线的阶数 + 1
    n_all_poly = n_seg * control_point_num;                                 % 使用分段贝塞尔曲线，对应有（ n_seg 个段数 * control_point_num 控制点个数 ）的 多项式系数
    
    % 利用贝塞尔曲线的 Hodograph 性质 贝塞尔曲线的导数仍然是贝塞尔曲线（低一阶）  
%% 起点的状态约束  
       
    % Aeq_start 3行 （总的多项式长度） 列     （列数是为了最后不同等式约束进行组合）
    % --------------
    % 位置约束
    % 速度约束
    % 加速度约束
    % --------------
    s = ts(1);
    Aeq_start = zeros(d_order - 1 ,n_all_poly);
    Aeq_start(1,1) = 1*s^(1-0);                                             % 第0个控制点 表达位置
    Aeq_start(2,1:2) = n_order * [-1,1] * s^(1-1);                          % 第0个控制点的1阶导 c_i^(1) = n *（c_i+1 - c_i) 表达 速度
    Aeq_start(3,1:3) = n_order * (n_order-1) * [1, -2, 1]* s^(1-2) ;        % 第0个控制点的2阶导 c_i^(2) = n *（n-1）（c_i+2 -2*c_i+1 - c_i) 表达 加速度                          
    beq_start =  start_cond';                                               % 满足最后的QP标准形式，变为列向量形式
    
%% 终点的状态约束 
    
    % Aeq_end 3行 （总的多项式长度） 列      （列数是为了最后不同等式约束进行组合）
    % --------------
    % 位置约束
    % 速度约束
    % 加速度约束
    % --------------
    s = ts(end);
    Aeq_end = zeros(d_order - 1,n_all_poly);
    Aeq_end(1,end) = 1 * s^(1-0);                                           % 第n个控制点 表达位置
    Aeq_end(2,end -1:end) = n_order * [-1,1] * s^(1-1);                     % 第n个控制点的1阶导 c_i^(1) = n *（c_i+1 - c_i) 表达 速度
    Aeq_end(3,end -2:end) = n_order * (n_order-1) * [1, -2, 1] * s^(1-2);   % 第n个控制点的2阶导 c_i^(2) = n *（n-1）（c_i+2 -2*c_i+1 - c_i) 表达 加速度   
    beq_end = end_cond';                                                    % 满足最后的QP标准形式，变为列向量形式
    
%% 位置连续性约束
    
    % Aeq_con_p （段数-1） 行 （总的多项式长度） 列    （列数是为了最后不同等式约束进行组合）
    % --------------
    % 第一段与第二段的连接点
    % ·
    % ·
    % ·
    % 第（n_seg-1）段与第（n_seg）段的连接点
    % --------------
    Aeq_con_p = zeros(n_seg-1, n_all_poly);
    % 也就是要求每段连接点状态的相减为0 也就是前后连续相等
    for k = 1:n_seg-1
        Aeq_con_p(k,k * control_point_num) = 1 * ts(k);                     % 连接点的前时刻
        Aeq_con_p(k,k * control_point_num+1) = -1 * ts(k+1);                % 连接点的后时刻
    end
    beq_con_p = zeros(n_seg-1,1);

%% 速度连续性约束
    
    % Aeq_con_v （段数-1） 行 （总的多项式长度） 列    （列数是为了最后不同等式约束进行组合）
    % --------------
    % 第一段与第二段的连接点
    % ·
    % ·
    % ·
    % 第（n_seg-1）段与第（n_seg）段的连接点
    % --------------
    
    % 对应于 c_i^(1) = n *（c_i+1 - c_i) 表达 速度
    Aeq_con_v =  zeros(n_seg-1, n_all_poly);
    
    % 也就是要求每段连接点状态的相减为0 也就是前后连续相等
    for k = 1:n_seg-1 
        Aeq_con_v(k,k * control_point_num-1:k * control_point_num) = n_order * [-1, 1];
        Aeq_con_v(k,k * control_point_num+1:k * control_point_num+2) = n_order * [1, -1];
    end    
    beq_con_v = zeros(n_seg-1,1);

%% 加速度连续性约束
    
    % Aeq_con_a （段数-1） 行 （总的多项式长度） 列    （列数是为了最后不同等式约束进行组合）
    % --------------
    % 第一段与第二段的连接点
    % ·
    % ·
    % ·
    % 第（n_seg-1）段与第（n_seg）段的连接点
    % --------------
    
    % 对应于 c_i^(2) = n *（n-1）（c_i+2 -2*c_i+1 - c_i) 表达 加速度 
    Aeq_con_a = zeros(n_seg-1, n_all_poly);
    for k = 1:n_seg-1 
        Aeq_con_a(k,k * control_point_num-2:k * control_point_num) = n_order * (n_order-1)*[1, -2, 1]/ ts(k);
        Aeq_con_a(k,k * control_point_num+1:k * control_point_num+3) = n_order * (n_order-1)*[-1, 2, -1]/ ts(k+1);
    end  
    beq_con_a = zeros(n_seg-1,1);

%% 组合所有约束构成等式约束 
    Aeq_con = [Aeq_con_p; Aeq_con_v; Aeq_con_a];
    beq_con = [beq_con_p; beq_con_v; beq_con_a];
    Aeq = [Aeq_start; Aeq_end; Aeq_con];
    beq = [beq_start; beq_end; beq_con];
end