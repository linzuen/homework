% pos = [0,1,1,1];
% rectangle('Position',pos,'Curvature',[1,1],'FaceColor','r','EdgeColor','none');
% axis equal
figure(3)
subplot(1,3,1)
subplot(1,3,2)
