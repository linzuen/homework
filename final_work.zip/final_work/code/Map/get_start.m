%% ######################################################
% @func： 返回加入起点之后的地图map
% @param： map：障碍物地图
%          MAX_X：最大x长度 
%          MAX_Y：最大y长度
% @return：map：额外加入起点的map（起点加到第一个位置）
% ######################################################
function map = get_start(map,MAX_X, MAX_Y)

    figure('Position',[200 100 1000 600]);                                  % 固定生成的figure位置，大小
    set(0, 'DefaultFigureRenderer', 'opengl');                              % 修改渲染器为 opengl
    set(gcf, 'Color', 'white')                                              % 设置背景白色
    hold on                                                                 % 保持图像
    grid on                                                                 % 画出栅格
    
    xticks(0:1:MAX_X);                                                      % 固定x的刻度
    yticks(0:1:MAX_Y);                                                      % 固定y的刻度
    size_map = size(map,1);                                                 % 读出一共有多少个障碍物

    obst_color = [55,184,157]/255;                                          % 障碍物颜色
    diameter = 1;                                                           % 障碍物直径
   
    % 画出障碍物
    for i = 1:size_map
        pos = [map(i,1)-1,map(i,2)-1,diameter,diameter];                    % 障碍物的位置坐标
        rectangle('Position',pos,'Curvature',[1,1],'FaceColor',obst_color,'EdgeColor','none'); % 圆形
    end

%     title("请选择一个起点");
%     [xStart,yStart] = check_choose(map);                                    % 检查选择点是否为合理的
    xStart = 1;
    yStart = 1;
    map = vertcat([xStart,yStart],map) ;                                    % 垂直拼接，起点坐标放到第一位
    
    scatter(xStart-0.5, yStart-0.5,'b','*');                                % 画出在当前图中
%     title("选择成功");                                                       % 提示用户

end