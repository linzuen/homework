%% ######################################################
% @func： 返回加入终点之后的地图map
% @param： map：地图
% @return：map：额外加入终点的map（终点加到最后一个位置）
% ######################################################
function map = get_final(map)
   
%     title("请选择一个终点");                                                  % 提示用户
    [xTarget,yTarget] = check_choose(map);                                   % 检查输入是否合理
    
    map(end + 1,:) = [xTarget,yTarget];                                      % 加入到最后
    
    scatter(map(end, 1)-0.5, map(end, 2)-0.5, 'r','*');                      % 画出在当前图中
%     title("选择成功");                                                       % 提示用户

end 