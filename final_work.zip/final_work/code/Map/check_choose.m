%% ######################################################
% @func： 检查用户输入是否合理（不能选在障碍物上，以及起点）
% @param： map：地图坐标
% @return：get_x：用户输入的x坐标
%          get_y：用户输入的y坐标
% ######################################################
function [get_x,get_y] = check_choose(map)
    size_map = size(map,1);                                                  % 读出地图元素个数
    choose_flag = 0;                                                         % flag用来帮助结束循环
    while( choose_flag == 0 || choose_flag == -1)                               
        choose_flag = 0;                                                     % 重置状态
        g = ginput(1);                                                       % 用户从图中获得一个输入 （分别为x，y坐标）

        get_x = floor(g(1)) + 1;                                             % 化整x输入
        get_y = floor(g(2)) + 1;                                             % 化整y输入

        for i = 1: size_map-1                                                % 循环检测用户输入
            if get_x == floor(map(i, 1)) && get_y == floor(map(i, 2))        % 如果输入已经是地图元素，  
                choose_flag = -1;                                            % 报错
                title("选择错误，请重新选择");                                % 提示用户 
                break;                                                       % 退出for循环   
            end
        end 

        if choose_flag ~= -1                                                 % 只要choose_flag不等于-1 说明选择成功，退出while循环
            choose_flag = 1;
        end
    end
    
end