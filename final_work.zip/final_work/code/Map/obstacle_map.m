%% ######################################################
% @func： 随机生成障碍物地图坐标
% @param： MAX_X：最大x长度
%          MAX_Y：最大y长度
% @return：map：2列地图信息
% ######################################################
function map = obstacle_map(MAX_X,MAX_Y)
    rand_map = rand(MAX_X,MAX_Y);                        % 生成的 MAX_X x MAX_Y 随机向量
    
    % map 2列 
    % --------------
    % X val | Y val |
    % --------------
    map = [];                                            % 预声明
    k =1;                                                % matlab索引从1开始
    obstacle_ratio = 0.3;                                % 地图中的障碍物占比
    % 遍历生成的rand_map
    for i = 1:1:MAX_X
        for j = 1:1:MAX_Y
            if( rand_map(i,j) < obstacle_ratio && ( (i ~= 1) || (j~=1) ) )          % 小于obstacle_ratio就添加进去，做到随机生成
                map(k,1) = i;
                map(k,2) = j; 
                k=k+1;  
            end    
        end
    end
end

