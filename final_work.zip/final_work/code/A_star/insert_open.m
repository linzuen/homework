%% ######################################################
% @func： 将节点加入到OPEN中
% @param： xval：该点x坐标
%          yval：该点y坐标
%          parent_xval：该点父x坐标
%          parent_yval：该点父y坐标
%          hn：与终点的距离
%          gn：到该点代价
%          fn：hn+gn的和 总代价
% @return：new_row：加入点的OPEN结构
% ######################################################
function new_row = insert_open(xval,yval,parent_xval,parent_yval,hn,gn,fn)
% OPEN =格式
% --------------------------------------------------------------------------
% IS ON LIST 1/0 |X val |Y val |Parent X val |Parent Y val |h(n) |g(n)|f(n)|
% -------------------------------------------------------------------------
%
new_row=[1,8];              % 初始化 1行 8列 向量
new_row(1,1)=1;             % 初始化为 未被遍历的 open list 成员
new_row(1,2)=xval;          % x 坐标值
new_row(1,3)=yval;          % y 坐标值
new_row(1,4)=parent_xval;   % 父 x 坐标值
new_row(1,5)=parent_yval;   % 父 y 坐标值
new_row(1,6)=hn;            % 距离代价
new_row(1,7)=gn;            % 代价
new_row(1,8)=fn;            % fn = gn + hn 总代价

end