%% ######################################################
% @func： 判断 传入的点（x，y坐标） 是否在 集合set 中，
% @param： set：集合
%          xval：该点坐标x
%          yval：该点坐标y
% @return：n_index：索引 不在就返回 -1
% ######################################################
function n_index = node_index(set,xval,yval)
    i=1;                                         % 初始值
    set_count = size(set,1);                     % 获得集合元素的个数（默认为行数）
    while(set(i,2) ~= xval || set(i,3) ~= yval ) % 判断是否在集合中
        i=i+1;                                   % 标号加1
        if(i>set_count)                          % 如果标号大于 集合元素个数，表示该点不在集合中；
            i = -1;                              % 赋值-1
            break                                % 退出循环
        end
    end
    n_index=i;                                   % 返回值赋值
end