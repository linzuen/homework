%% ######################################################
% @func： 计算队列中最小代价，以及其在原队列的索引
% @param： OPEN：开集
% @return: i_min:返回 OPEN 中的f(h)最小的一个的索引，也就是该点到目标点花费代价最小
% ######################################################
function i_min = min_fn(OPEN)
% temp_array 结构 9列 与OPEN 一样 只是多了一个索引列
% ------------------------------------------------------------------------------
% IS ON LIST 1/0 |X val |Y val |Parent X val |Parent Y val |h(n)|g(n)|f(n)|index
% ------------------------------------------------------------------------------
 OPEN_COUNT = size(OPEN,1);
 temp_array=[];                                                             % 初始化
 k=1;                                                                       % 初始化
 for j=1:OPEN_COUNT
     if (OPEN(j,1)==1)                                                      % 判断是否为未访问过的节点 
         temp_array(k,:)=[OPEN(j,:) j];                                     % 保存该点的数据以及该点在OPEN下面的索引
         k=k+1;                                                             
     end
 end
 if size(temp_array) ~= 0                                                   % 如果 temp_array 不为空，说明还有没有打开的点
    [min_fn,temp_min_index]=min(temp_array(:,8));                           % 返回 temp_array 中fn 最小值 以及其在 temp_array 的线性索引。
    i_min=temp_array(temp_min_index,9);                                     % 得出该fn 最小值在OPEN中的索引 
 else
     i_min=-1;                                                              % temp_array 为空，没有点可以去查询了
 end