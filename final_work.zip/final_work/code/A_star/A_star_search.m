%% ######################################################
% @func： 使用A*算法计算起点到终点的路径
% @param： map：地图
%          MAX_X：地图x的边界
%          MAX_Y：地图y的边界
% @return：path：起点到终点的路径
%          OPEN：寻找的点列
% ######################################################
function [path,OPEN] = A_star_search(map,MAX_X,MAX_Y)
%%

    % 预处理网格图，添加偏移
    size_map = size(map,1);                                                 % 地图元素个数

    
    % MAP 生成网格图 （默认填充都是2）
    % 障碍位置设置为-1, 终点为0, 起点为 1
    MAP=2*(ones(MAX_X,MAX_Y));                                              % MAX_X x MAX_Y 
    
    % 定义起点，起点在map的第一个元素
    xStart=floor(map(1, 1));
    yStart=floor(map(1, 2));
    
    MAP(xStart,yStart)=1;                                                   % MAP中起点设置为1
       
    % 定义终点，终点在map的最后一个元素
    xTarget=floor(map(end, 1));
    yTarget=floor(map(end, 2));

    MAP(xTarget,yTarget)=0;                                                 % MAP中终点设置为0
    
    % 填充障碍物
    for i = 2: size_map-1
        xval=floor(map(i, 1));
        yval=floor(map(i, 2));
        MAP(xval,yval) = -1;                                                % MAP障碍物设置为-1                                       
    end 
    
    % OPEN 结构为 8列
    % --------------------------------------------------------------------------
    % IS ON LIST 1/0 |X val |Y val |Parent X val |Parent Y val |h(n) |g(n)|f(n)|
    % --------------------------------------------------------------------------
    % IS ON LIST 1/0 （1为未被遍历，0为已经遍历过了）
    % |X val |Y val 该点的x y 坐标
    % |Parent X val |Parent Y val | 该点的父点x，y坐标
    % hn（与终点的距离）
    % gn（到达该点的代价）
    % fn（hn与gn的和）
    OPEN=[];
    % CLOSED 结构为 2列
    % --------------
    % X val | Y val |
    % --------------
    CLOSED=[];

    % 将障碍物加入CLOSED 集合中
    k=1;                                                                    % matlab中索引从1开始
    
    % 循环加入到 CLOSED
    for i=1:MAX_X                                                           
        for j=1:MAX_Y
            if(MAP(i,j) == -1)
                CLOSED(k,1)=i;                                              % 存储x坐标
                CLOSED(k,2)=j;                                              % 存储y坐标
                k=k+1;
            end
        end
    end
    
    CLOSED_COUNT=size(CLOSED,1);                                            % CLOSED 元素 个数

    % 设置起点 到 OPEN
    OPEN_COUNT=1;                                                           % 第一个元素
    goal_distance=distance(xStart,yStart,xTarget,yTarget);                  % 计算与终点的距离 作为 hn
    path_cost=0;                                                            % 到达该点的代价 自己到自己为0
    OPEN(OPEN_COUNT,:)=insert_open(xStart,yStart,xStart,yStart,goal_distance,path_cost,goal_distance + path_cost);  % 将起点坐标信息 按照 OPEN 的结构 加入到 OPEN
    
    CLOSED_COUNT = CLOSED_COUNT+1;                                          % 加入起点到 CLOSED，不会走回头路
    CLOSED(CLOSED_COUNT,1)=xStart;                                          % 加入起点x坐标
    CLOSED(CLOSED_COUNT,2)=yStart;                                          % 加入起点y坐标
    
%% 寻找终点
    NoPath = 1;                                                             % 如果NoPath == 1就表示没有找到路径
    final_index = -1;                                                       % 计算终点在OPEN中的索引
    while(1)

         if((sum(OPEN(:,1)))==0 || NoPath == 0)                             % 如果 OPEN 都遍历过之后
             break                                                          % 退出循环
         end

         i_min = min_fn(OPEN);                                              % 从队列中弹出一个最小fn的节点
         if i_min == -1                                                     % 找不到就报错
             disp("未找到目标");
             break;
         end
         OPEN(i_min,1) = 0;                                                 % 标记为已经弹出
         Data_Pop = OPEN(i_min,[2,3,7]);                                    % 从未遍历的OPEN中弹出具有最小代价的 元素
                                                                            % 按照 OPEN 的结构 第2个是 xval，第3个是yval，第7个是g（n） 
         % 加入到 CLOSED，代表已经遍历
         CLOSED_COUNT = CLOSED_COUNT + 1;                                   % CLOSED 数量 加1 
         CLOSED(CLOSED_COUNT,:) = [Data_Pop(1),Data_Pop(2)];                % 将 x y 坐标加入到 CLOSE 

         % 拓展周围的邻居
         Exp_array = expand_array(Data_Pop(1),Data_Pop(2),Data_Pop(3),xTarget,yTarget,CLOSED,MAX_X,MAX_Y); % 获得拓展之后的点集合
         
         % EXPANDED ARRAY FORMAT 
         %--------------------------------
         %|X val |Y val ||h(n) |g(n)|f(n)|
         %--------------------------------
         if(~isempty(Exp_array))                                            % 判断 拓展集 是否为空
            for m=1:1:length(Exp_array(:,1))                                % 根据 拓展集的行数 进行 for 循环
                x_exp = Exp_array(m,1);                                     % 拓展点的x坐标值
                y_exp = Exp_array(m,2);                                     % 拓展点的y坐标值
                hn = Exp_array(m,3);                                        % 拓展点的hn（与目标点的距离）
                gn = Exp_array(m,4);                                        % 拓展点的gn（到达该点的代价）
                fn = Exp_array(m,5);                                        % 拓展点的fn（hn与gn的和）
                if(x_exp == xTarget && y_exp == yTarget)                    % 如果拓展点中 就有 目标点
                    NoPath = 0;                                             % 说明找到了路径
                    OPEN_COUNT = OPEN_COUNT + 1;                            % 将该点 加入到 open list中
                    OPEN(OPEN_COUNT,:) = insert_open(x_exp,y_exp,Data_Pop(1),Data_Pop(2),hn,gn,fn);% 将该点 加入到 open list中
                    final_index = OPEN_COUNT;                               % 目标点在 open list中的索引
                    break;                                                  % 退出for循环
                end

                n_index = node_index(OPEN,x_exp,y_exp);                     % 判断 拓展的点是否在open list 中，不在的话加入 ，在的话返回索引
                if(n_index == -1)                                           % 返回 -1 说明不在open list中
                    OPEN_COUNT = OPEN_COUNT  + 1;                           % 加入到open list
                    OPEN(OPEN_COUNT,:) = insert_open(x_exp,y_exp,Data_Pop(1),Data_Pop(2),hn,gn,fn); % 父类是 弹出的那个点（也就是被拓展那个）
                else                                                        % 说明该拓展点在 open list中
                    if(OPEN(n_index,8)> fn )                                % 如果该 open list 中的 fn 大于 现在计算的fn 更新为最新的cost
                        OPEN(n_index,4) = x_exp;                            % 将其父类，更为现在的点 获得 最低cost
                        OPEN(n_index,5) = y_exp;                            % 父类 y 坐标
                        OPEN(n_index,7) = gn;                               % 新 gn（到该点的代价）
                        OPEN(n_index,8) = fn;                               % 新 fn（到目标的总代价）
                    end
                    
                end
                
            end
            
         end

    end                                                                     % 循环结束
    
%% 算法运行后，通过从最后一个节点（如果是目标节点）开始，
    % 然后识别其父节点，直到到达起始节点，生成最佳路径。这是最佳路径
    
    path = [];                                                              % 最佳路径点
    if NoPath                                                               % 如果 nopath == 1说明没找到路径到达目标点
        return                                                              % 退出 这时 path 就为空集了
    else
        n = 1;                                                              % 辅助计数 初始化为 1
        path(n,:) = [xTarget,yTarget];                                      % 从目标点开始，识别其父节点
        while(final_index > 1)                                              % final_index 为 目标点在 open list中的索引
            % 父点
            xval = OPEN(final_index,4);                                     % 父点的x坐标值
            yval = OPEN(final_index,5);                                     % 父点的y坐标值
            temp = node_index(OPEN,xval,yval)                               % 找到父点在openlist的索引值
            if final_index == temp
                final_index = temp -1;
            else
                final_index = temp;
            end
            n = n +1;
            path(n,:) = [xval,yval];                                        % 将父点坐标值加入到 path里面
        end
    end
    path = flip(path);                                                      % 翻转元素顺序
end
