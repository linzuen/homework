%% ######################################################
% @func： 画图可视化
% @param： map：地图
%          open：搜索的区域
%          path：找到路径
%          Trajectory：生成轨迹
%          corridor： 飞行走廊
% ######################################################
function flg(map,open,path,Trajectory,corridor)

    obst_color = [55,184,157]/255;
    
    path_count = size(path,1);

    nt = size(Trajectory,1); 
    
    open_count = size(open,1);
    
    for i = 1:1:open_count
        temp = open(i,2) - 1 :0.5:open(i,2);
 
        temp_x = [temp,temp(end:-1:1)];
        temp = open(i,3) - 1 :0.5:open(i,3);

        temp_y = open(i,3)*ones(length(temp));

        tt = [temp_y-1,temp_y];
        h = fill(temp_x,tt,'r','FaceColor',[1 0.8 0.8],'EdgeColor','none');
        set(h,'edgealpha',0,'facealpha',0.3) 
        
        pause(0.5);
    end 
   
    for j = 2:path_count-1
        scatter(path(j,1)-0.5,path(j,2)-0.5,'b');
        pause(0.5);
    end
    
    for i = 1:path_count
        rectangle('Position',[corridor(1,i) - corridor(end, i),corridor(2,i) - corridor(end, i), 2*corridor(end, i), 2*corridor(end,i) ]);
        pause(0.5);
    end

    plot(path(:,1)-0.5,path(:,2)-0.5,'k')
    pause(1);
    
    for ii = 1:5:nt
        plot(Trajectory(1:ii,1),Trajectory(1:ii,2),"r")
        drawnow
        if ii < nt
            cla;
            for i = 2: size(map, 1) - 1
                pos = [map(i,1)-1,map(i,2)-1,1,1];
                rectangle('Position',pos,'Curvature',[1,1],'FaceColor',obst_color,'EdgeColor','none');
            end
            scatter(map(1, 1)-0.5, map(1, 2)-0.5,'b','*');
            scatter(map(end, 1)-0.5, map(end, 2)-0.5, 'r','*');
            for i = 1:path_count
                rectangle('Position',[corridor(1,i) - corridor(end, i),corridor(2,i) - corridor(end, i), 2*corridor(end, i), 2*corridor(end,i) ]);
            end
            for i = 2:path_count-1
                scatter(path(i,1)-0.5,path(i,2)-0.5,'b');
            end
        end
    end
    plot(Trajectory(:,1),Trajectory(:,2),"r")
    hold off;

end 