close all; clear all; clc;  

% 添加路径
addpath('A_star')
addpath('Make_figure')
addpath('Map')
addpath('Trajectory_generation')


MAX_X = 10;                                                     % 设置的x区域大小
MAX_Y = 10;                                                     % 设置的y区域大小

map_obstacle = obstacle_map(MAX_X, MAX_Y);                      % 生成障碍物位置 

map_start = get_start(map_obstacle,MAX_X, MAX_Y);               % 读入起点信息  
map = get_final(map_start);                                     % 读入终点信息  

[path,OPEN] = A_star_search(map,MAX_X,MAX_Y);                   % 路径搜索

if isempty(path)                                                % 搜索失败
    handle = msgbox('无路径可以产生','Fail','error');            % 弹出信息
    uiwait(handle)                                              % 用户必须响应
else
    [Trajectory,corridor] = Trajectory_generation(path);        % 生成飞行走廊，最优化轨迹
    flg(map,OPEN,path,Trajectory,corridor);                     % 画图
end

hold on
new_map = map;
new_map(1,1) = map(end,1);
new_map(1,2) = map(end,2);

new_map(end,1)= 1;
new_map(end,2)= 1;

[new_path,new_OPEN] = A_star_search(new_map,MAX_X,MAX_Y);

[new_Trajectory,new_corridor] = Trajectory_generation(new_path);

flg(new_map,new_OPEN,new_path,new_Trajectory,new_corridor); 
